My app name is Buzz Feed

So basically I have build an iOS/Android Mobile Application for my University's Transport Department in which including everyone from Professor to students can use my application to get their University's bus feed and remove that MORNING CHAOS.

