class IconFontHelper {
    static const String LOGO = 'a';
}