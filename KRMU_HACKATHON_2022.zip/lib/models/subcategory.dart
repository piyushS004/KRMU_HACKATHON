import 'package:first_app/models/category.dart';
import 'package:flutter/cupertino.dart';

class SubCategory extends Category {
  SubCategory({String name, icon, imgName, Color color
  
  }): super(name: name, icon: icon, color: color, imgname: imgName);
}
