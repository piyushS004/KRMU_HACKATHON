class OnboardingContent {
  String message, img;

  OnboardingContent({this.message, this.img});
}
